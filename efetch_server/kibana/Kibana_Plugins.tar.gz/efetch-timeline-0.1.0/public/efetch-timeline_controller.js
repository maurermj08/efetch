define(function (require) {

  var module = require('ui/modules').get('kibana/efetch-timeline', ['kibana']);

  //This could be a security issue for some groups, so for testing only now
  module.config(function($sceDelegateProvider) {
      $sceDelegateProvider.resourceUrlWhitelist(['**']);
  });

  module.controller('EfetchTimelineVisController', function ($scope, $location, $element, Private) {
    $scope.getBody = function(efetch_url) {
        return '<h1>TODO</h1>';
    };
  });
  module.controller('EfetchTimelineVisController', function ($scope, $location, $element, Private) {
    $scope.getSrc = function(efetch_url, path) {
        return efetch_url + path;
    };
  });
});
